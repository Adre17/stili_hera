
import { MapContainer, Marker, Popup, TileLayer,GeoJSON } from 'react-leaflet'
import Wkt from 'wicket'
import axios from 'axios';
import L from 'leaflet'
import React, { Component } from 'react'

import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';


componentDidMount() {
    this.refreshList();
  }
refreshList = () => {
    axios   //Axios to send and receive HTTP requests
      .get("http://127.0.0.1:8000/api/proves/")
      .then(res => this.setState({ taskList: res.data }))
      .catch(err => console.log(err));
  };


export default class map extends Component {



    constructor(props){
        super(props);
        this.state={
            wkt_json_holder:[],
            json_ob:<></>,
            json_key:1,
            tile:'https://tiles.stadiamaps.com/tiles/alidade_smooth_dark/{z}/{x}/{y}{r}.png',
        }
        this.setGeoJSON = this.setGeoJSON.bind(this)
        this.onEach = this.onEach.bind(this)
    }
    async componentDidMount(){
        await this.setState({wkt_json_holder:data});
        this.setGeoJSON()
    }

setGeoJSON=()=>{
        let json_data = this.state.wkt_json_holder.map(point=>{
            let wkt_geom = point['geom'].replace('SRID=4326;','')
            let wkt = new Wkt.Wkt();
            wkt.read(wkt_geom)
            let geojson_geom = wkt.toJson()
            let coords = geojson_geom['coordinates']
            let type = geojson_geom['type']
            let geojson_obj={
                "type": "Feature",
                "geometry": {
                    'type':type,
                    'coordinates':coords
                },
                "properties": {
                    "town_name": point['town_name'], "town_id": point['town_id'], "town_type":point['town_type'], "perimeter": point['perimeter'], "area": point['area']
                }
            }
              return geojson_obj
            }

            )
            console.log(json_data)
            let json_ob= <GeoJSON data={json_data} key={1} style={{color:'red'}} onEachFeature={this.onEach}/>
            this.setState({json_ob})
    }
}

export function mapvisual(){}
export const MapComponent = ({ positionDefault = [44.36, 11.34] }) => {
    return (
        <MapContainer center={positionDefault} zoom={10} style={{ height: '500px', width: '100%' }}>
            <TileLayer
            url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
            attribution='&copy; <a href=&quot;http://osm.org/copyright&quot;>OpenStreetMap</a> contributors'
            />
            <Marker position={[44.36, 11.34]}>
                    <Popup>
                         A pretty CSS3 popup. <br /> Easily customizable.
                    </Popup>
             </Marker>

        </MapContainer>
        )
    }


