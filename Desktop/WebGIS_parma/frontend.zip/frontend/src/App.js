import logo from './logo.svg';
import './App.css';
import 'leaflet/dist/leaflet.css';
import React, { Component, Fragment } from 'react';
import axios from 'axios';
import {mapvisual, MapComponent } from './MapComponent'




